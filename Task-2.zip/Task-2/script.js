//Color Changing
col =new Array("pink","#00CC99","skyblue","#CC9999","#B445FE");
function colorChange()
{
i=Math.random();
i=Math.round(i*4);
document.body.style.color=col[i];
setTimeout("colorChange()",600);
}

