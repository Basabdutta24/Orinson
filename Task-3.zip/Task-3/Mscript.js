
document.addEventListener('DOMContentLoaded', () => {
    // Handle Contact Form Submission
    const contactForm = document.getElementById('contact-form');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();

        if(name && email && message) {
            alert(`Thank you, ${name}! Your message has been received.`);
            contactForm.reset();
        } else {
            alert('Please fill in all fields.');
        }
    });

//Add an item to cart
let cartCount = 0;

document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', function () {
    cartCount++;
    document.getElementById('cart-count').textContent = cartCount;
  });
});
	

    // Handle Add to Cart Buttons
    const addToCartButtons = document.querySelectorAll('.product-card .btn');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            alert('Item added to cart!');
            // Here you can implement cart functionality
        });
    });
});

//Image Slideshow 
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}


// Simulated user login information
const validUsername = "user";
const validPassword = "password";

// Flag to track login status
let isLoggedIn = false;

// Handling the login
document.getElementById("login-button").addEventListener("click", function() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    if (username === validUsername && password === validPassword) {
        isLoggedIn = true;
        document.getElementById("login-status").innerText = "Login successful!";
        
        // Show product section after login
        document.getElementById("login-section").style.display = "none";
        document.getElementById("product-section").style.display = "block";
    } else {
        isLoggedIn = false;
        document.getElementById("login-status").innerText = "Invalid username or password.";
    }
});

// Handling add to cart
document.getElementById("add-to-cart-button").addEventListener("click", function() {
    if (isLoggedIn) {
        document.getElementById("cart-status").innerText = "Item successfully added to cart!";
    } else {
        document.getElementById("cart-status").innerText = "Please log in to add items to the cart.";
    }
});
