document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    errorMessage.textContent = ''; // Clear previous error message

    if (username === '' || password === '') {
        errorMessage.textContent = 'Please fill in both fields.';
        return;
    }

    if (username === 'admin' && password === 'password123') {
        alert('Login successful!');
        // Redirect to another page or perform any other actions after successful login
		window.location.href = "Main.html";
    } else {
        errorMessage.textContent = 'Invalid username or password.';
    }
});
